# Keep the VPN service entry point — Android instantiates it by name
-keep class app.onvo.vpn.OnvoVpnService { *; }
-keep class app.onvo.update.** { *; }
-keepattributes *Annotation*, Signature, Exception
-dontwarn kotlinx.serialization.**
